# Bulkhead 2.0.0 checkpoint — 2026-10-27

Fixed route: input filter -> unsigned 8-bit ADC -> captured dry plus shared
mono-history stereo wet -> one unsigned 8-bit DAC -> output filter.
Mix 0 still converts. Output controls wet level before the final DAC.
Direct/ADC and Shared/Legacy switches and audio migration paths are removed.
Distinct processor/controller IDs and Bulkhead2.vst3 allow coexistence with
the old release. Version 2 presets/preferences have their own directory.

Nominal 22.05 kHz, 20 packets and no dither are defaults. Nominal 11.025 kHz
remains economy/extreme. Converter coding and nominal modes are preserved.
The single wet-history allocation is 256 KiB. Fragment/packet/pan coefficients
are combined at control rate. Settled-filter caching and active-ramp updates
are retained; no new performance percentage is claimed.

## Fresh checks

- Built x64 Release with static CRT on Windows 10 Pro 22H2, build 19045.
- All 5 CTest suites passed: DSP 37 checks, direction 33, editor/host 153,
  preset suite and compiled-plugin integration.
- Integration: 288 cases / 6,912,000 frames matched the source engine exactly,
  including mono/stereo, 32/64-bit buffers, six host rates, automation and silence.
- VST3 validator: 47 passed / 0 failed.
- Original 1.0.1 and version 2 loaded together with distinct processor IDs;
  the integration matrix passed with both modules loaded.
- Unfiltered ADC/DAC oracle exact. Independently compiled filtered oracle
  worst absolute difference 4.37e-14 (limit 1e-12).
- Combined-output default/factory fixtures at both clocks: worst absolute
  stereo imbalance below 0.31 dB. This is not listening acceptance.
- Options preview inspected: removed routing choices absent; version visible.
- Imports: standard Windows DLLs only; no separate Visual C++ runtime required.

## Remaining validation

No strict 486 real-time feasibility is established. Cache/memory behavior,
control changes, crossfade peaks, complete integer implementation and DMA
deadline/underrun measurements need a suitable 486 or defensible timing model.
16-24 packets is a design ambition, not a validated 486 budget. One SB Pro II
is half-duplex: continuous live VST I/O is a modern extension.

DOS work remains paused. Preserved DOS study sources are historical and not
validated against the version 2 API. No DOS executable is in the plugin package.
44.1 kHz mono, real-card measurements and DAW listening acceptance remain open.

Unpublished development checkpoint; not installed, published or cryptographically
signed. See the authenticity audit, changelog, licenses and evidence logs.
