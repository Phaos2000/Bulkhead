# Bulkhead 2.0.1 � naming correction

The product is named **Bulkhead**. The VST3 processor, controller and bundle
names no longer include a product-name suffix. Version is 2.0.1.
Bundle: `Bulkhead.vst3`; controller: `Bulkhead Controller`.

DSP, parameters, factory presets, processor/controller IDs, version 2 state
format and preset/settings directory are unchanged from 2.0.0. Existing
version 2 sessions remain valid. The internal Bulkhead2 settings directory
is retained to preserve version 2 preferences and avoid mixing with version 1.

## Validation on Windows 10 x64

- All 5 CTest suites passed: 37 DSP, 33 direction, 154 host/editor checks,
  presets and compiled-plugin integration. Host check explicitly verifies
  that the processor name is Bulkhead.
- VST3 validator: 47 passed / 0 failed.
- Both 2.0.0 and 2.0.1 binaries matched the unchanged source engine exactly
  across 288 cases / 6,912,000 frames each. This includes mono/stereo,
  32/64-bit buffers, six host rates, automation and silence flags.
- Module metadata reports Bulkhead, version 2.0.1 and the existing version 2 IDs.
- Preview inspected; established interface retained, version readout updated.
- Archive integrity and packaged DLL checksum verified.

## Installation

Replace the earlier 2.0.0 bundle (Bulkhead2.vst3) with Bulkhead.vst3 and rescan
your host. Do not leave both version 2 bundles installed with the same ID.
For version 1 alongside version 2, put each complete bundle in a separate
version subfolder inside the VST3 search folder. Both are named Bulkhead.vst3;
their processor IDs differ. No files were installed automatically.

This naming correction does not change sound. DOS development remains paused.
486 real-time performance, real-card measurements and DAW listening acceptance
remain unproved. See the authenticity audit for the historical limitations.
No Authenticode signature is claimed.
